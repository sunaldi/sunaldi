window.SelectFilter = {
    init: function (field_id, field_name, is_stacked) { }
};
